﻿namespace Skype.Data.Defined.Enums
{
    public enum Roles
    {
        Admin,
        Member
    }
}
