module.exports = {
  prefix: "",
  mode: "jwt",
  purge: {
    content: ["./src/**/*.{html,ts}"],
  },
  darkMode: "class",
  theme: {
    extend: {},
  },
  variants: {
    extend: {},
  },
};
